'''
python wrapper for JSON to HTML-Table convertor
(c) 2013 Varun Malhotra. MIT License
'''

from jsonconv import *

__author__ = 'Varun Malhotra'
__version__ = '1.0.1'
__license__ = 'MIT'
