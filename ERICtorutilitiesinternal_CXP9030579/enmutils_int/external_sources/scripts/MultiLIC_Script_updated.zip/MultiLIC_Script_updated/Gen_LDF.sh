#!/bin/sh -a

APPENDFILE_NAME=_info.xml
TABLES="/tmp/tables"
ls  /tmp/temp_lkf >${TABLES}

for table in `cat ${TABLES}`
do
tempfile=`basename  $table .xml`
done

rm  ${TABLES}

#if [ $# -ne 3 ];then
#echo "usage is: ./Gen_LDF.sh <NodeType> <Fingerprint> <SeqNo>"
#exit 1
#fi
NodeType=$1
FP=$2
SeqNo=$3

echo "Changing values in _info.xml..."
cd /tmp/temp_lkf
cat <<EOF >${tempfile}_info.xml
<?xml version="1.0" encoding="UTF-8"?>
<LicenseDataFile xmlns="http://www.ericsson.se/oss/shm/ldf/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.ericsson.se/oss/shm/ldf/ LicenseDataFile.xsd">
<Body>
<LicenseKeyFileName>${tempfile}.xml</LicenseKeyFileName>
<TargetNodeType>${NodeType}</TargetNodeType>
<Fingerprint print="${FP}"/>
<SequenceNumber>${SeqNo}</SequenceNumber>
<Generated>2009-08-27T08:50:14</Generated>
<LicenseKey id="CXC4010071/4003">
<Type>CAPACITY</Type>
<Description>wran_license_for_bss</Description>
<value>16</value>
<start>2014-09-03</start>
<stop/>
</LicenseKey>
<LicenseKey id="CXC4010071/4002">
<Type>CAPACITY</Type>
<Description>wran_license_for_bss</Description>
<value>16</value>
<start>2014-09-03</start>
<stop/>
</LicenseKey>
</Body>
<Signature>default</Signature>
</LicenseDataFile>
EOF
