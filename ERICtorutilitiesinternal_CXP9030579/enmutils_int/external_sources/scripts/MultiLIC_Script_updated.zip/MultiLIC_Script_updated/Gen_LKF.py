# Generate CPP license files.
# Written by Joakim Hellsten 2007-11-..
#
# To execute this script on solaris machines (at least at SHM FT), do:
# /opt/python/jpython/jython generate_licenses [options]
#
# Directory structure for a license batch file:
# (abbreviations: d directory, f file)
# 
# date: YYMMDD
# time: HHMMSS
#
# d - <name>_<date>_<time>
#   f - <date>_<time>.info.xml
#   d - <ELSN ID>
#     d - <date>_<time>
#       d - ERI
#         f - <fingerprint>_<date>_<time>.xml
#       d - specification
#         f FS_<ELSN ID>.pdf # just touch it or ignore.
#       f - info.xml
#

from os import mkdir, makedirs, rmdir
from os.path import isfile

NO_STOP = 'never'

import sys
from os.path import join

class TimeStamp(object):
    """Timestamp which produces useful values for the xml files."""

    def __init__(self, datetime):
        self.datetime = datetime

    def __str__(self):
        return self.get_delivery_stamp()

    def get_time(self):
        """HHMMSS"""
        return self.datetime.strftime("%H%M%S")

    def get_long_time(self):
        """HH:MM:SS"""
        return self.datetime.strftime("%H:%M:%S")

    def get_date(self):
        """YYMMDD"""
        return self.datetime.strftime("%y%m%d")

    def get_long_date(self):
        """YYYY-MM-DD"""
        return self.datetime.strftime("%Y-%m-%d")
    
    def get_delivery_stamp(self):
        """YYMMDD_HHMMSS, used for delivery id ..."""
        return self.get_date() + "_" + self.get_time()

    def get_generated_stamp(self):
        """Kind of special format: YYYY-MM-DDTHH:MM:SS"""
        return self.get_long_date() + "T" + self.get_long_time()

class TimeKeeper(object):
    """TimeStamp producer, initializes to current time and guarantees that there
    is always a one second difference between timestamps."""

    def __init__(self):
        from datetime import datetime
        self.datetime = datetime.now()

    def next_timestamp(self):
        from datetime import timedelta
        self.datetime = self.datetime + timedelta(seconds=1)
        return TimeStamp(self.datetime)

    def __str__(self):
        return self.get_date() + " " + self.get_time()

class LKFField(object):
    """Just for removing some duplication ..."""

    stop = "<stop>%(end_date)s</stop>"
    nostop = "<noStop/>"

    def get_stop_field(self, end_date):
        if end_date.lower() == NO_STOP:
            self.stop % {'end_date': end_date}
        else:
            return self.nostop
 
class Capacity(LKFField):
    """A capacity entry in the LKF file."""

    template = """<capacityKey id="%(key)s">
<description>%(description)s</description> 
<start>%(start_date)s</start> 
%(stop)s
<capacity>%(capacity)s</capacity> 
<hardLimit>%(hard_limit)s</hardLimit> 
</capacityKey>
"""

    def __init__(self, key, description, capacity, hard_limit, 
                 start_date, end_date):
       self.values = {'key': key,
                      'description': description,
                      'capacity': capacity,
                      'hard_limit': hard_limit,
                      'start_date': start_date,
                      'stop': self.get_stop_field(end_date),
                      }

    def __str__(self):
        return self.template % self.values

class Feature(LKFField):
    """A feature entry in the LKF file."""

    template = """<featureKey id="%(key)s">
<description>%(description)s</description>
<start>%(start_date)s</start> 
%(stop)s
</featureKey>
"""

    def __init__(self, key, description, start_date, end_date):
        self.values = {'key': key,
                       'description': description,
                       'start_date': start_date,
                       'stop': self.get_stop_field(end_date),
                       }

    def __str__(self):
        return self.template % self.values

class WritableFile(object):

    def write(self):
        from os import makedirs, error
        from os.path import dirname
        print "Writing file:", self.file_path
        try:
            makedirs(dirname(self.file_path))
        except error, e:
            print "Can't create dirname:", e
            pass
        f = open(self.file_path, 'w+')
        f.write(str(self))
        f.write("\n")
        f.close()

class LicenseKeyFile(WritableFile):
    """Represents an LKF file. LKFs are always named as
    <FINGERPRINT>_<YYMMDD>_<HHMMSS>.xml.
    """

    header = """<?xml version="1.0" encoding="UTF-8"?>
<licFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<body formatVersion="1.0" signatureType="1">
<sequenceNumber>%(seq_no)s</sequenceNumber>
<ELSN elsnId="%(elsn_id)s">
<generalInfo>
<generated>%(generated)s</generated>
<issuer>Ericsson AB</issuer>
</generalInfo>
<fingerprint method="1" print="%(fingerprint)s">
"""

    footer = """</fingerprint>
</ELSN>
</body>
</licFile>"""

    def __init__(self, delivery_id, timestamp, fingerprint='FAKE_LKF',
                 elsn_id='ELSN_ID', seq_no=1, num_features=2, 
                 capacity_pairs=((10,20)), start_date='2001-01-01', 
                 stop_date=NO_STOP):
        """
        path - path where to place the file.
        features - number of features and 
        capacity_pairs - pairs of (capacity, hard_limit).
        """
        filename = fingerprint + "_" + timestamp.get_delivery_stamp() + '.xml'
        self.file_path = join("/tmp/temp_lkf", filename)
        self.header_data = {'fingerprint': fingerprint,
                            'elsn_id': elsn_id,
                            'seq_no': seq_no,
                            'generated': timestamp.get_generated_stamp(),
                            }
                       
        self.num_features = num_features
        self.capacity_pairs = capacity_pairs
        self.start_date = start_date
        self.stop_date = stop_date

    def __str__(self):
        res = [self.header % self.header_data]
        for i in xrange(self.num_features):
            res.append(str(Feature('FEATURE-' + str(i), 'FEATURE ' + str(i),
                                   self.start_date, self.stop_date)))
        for i in xrange(len(self.capacity_pairs)):
            (capacity, hard_limit) = self.capacity_pairs[i]
            res.append(str(Capacity('CAPACITY-%s' % i,
                                    'CAPACITY %s' % i,
                                    capacity, hard_limit,
                                    self.start_date,
                                    self.stop_date)))
        res.append(self.footer)
        return "".join(res)

class DeliveryFile(WritableFile):
    template = """<?xml version="1.0" encoding="UTF-8"?>
    <licDelivery formatVersion="1.0">
        <common>
            <notification notifyType="emailSimple">
                <combinedDeliveryNotification>YES</combinedDeliveryNotification>
                <emailSimpleDelivery>
                    <customerID>ERICSSON AB (EAB)</customerID>
                 </emailSimpleDelivery>
            </notification>
        </common>
        <licTargetList>
        %s
       </licTargetList>
    </licDelivery>"""

    target = """    <licTarget>
                <licTargetId>%(elsn_id)s</licTargetId>
                <fingerprint>%(fingerprint)s</fingerprint>
                <custNodeName></custNodeName>
            </licTarget>"""

    def __init__(self, delivery_id):
        self.file_path = join(delivery_id, delivery_id + '.info.xml')
        self.targets = []

    def add_target(self, fingerprint, elsn_id):
        self.targets.append(self.target % {'fingerprint': fingerprint,
                                           'elsn_id': elsn_id})

    def __str__(self):
        return self.template % " ".join(self.targets)

class LicenceTargetFile(WritableFile):
    
    template = """<?xml version="1.0" encoding="UTF-8"?><licTargetFile formatVersion="1.0"><licTarget><licTargetId>%(elsn_id)s</licTargetId><fingerprint>%(fingerprint)s</fingerprint><custNodeName></custNodeName></licTarget></licTargetFile>"""

    def __init__(self, delivery_id, timestamp, fingerprint, elsn_id):
        self.fingerprint = fingerprint
        self.elsn_id = elsn_id
        self.file_path = join(delivery_id, elsn_id,
                              timestamp.get_delivery_stamp(), 
                              'info.xml')

    def __str__(self):
        return self.template % {'fingerprint': self.fingerprint, 
                                'elsn_id': self.elsn_id}

class FakePDFFile(WritableFile):
    """Don't know if we need this, but it should be there ..."""

    def __init__(self, delivery_id, timestamp, elsn_id):
        self.file_path = join(delivery_id, elsn_id,
                              timestamp.get_delivery_stamp(),
                              'specification', 
                              'FS_' + elsn_id + '.pdf')

    def __str__(self):
        return "Wish I was a real PDF!"

class LicenseMaker(object):
    """Functionality for creating multiple license batch files."""
    
    def __init__(self, name='FAKE_LKF', num_batches=1, seq_no=0, 
                 capacity_increment=0, **kwargs):

        self.license_kwargs = kwargs
        self.delivery_name = name
        self.seq_no = int(seq_no)
        self.num_batches = int(num_batches)
        self.capacity_increment = capacity_increment

        self.timekeeper = TimeKeeper()

    def generate(self):
        print self.num_batches
        for i in xrange(self.num_batches):
            self.generate_next_batch()

    def generate_next_batch(self):
        timestamp = self.timekeeper.next_timestamp()
        delivery_id = self.delivery_name + "_" + timestamp.get_delivery_stamp()
        lbf = LicenseBatchFile(delivery_id, timestamp, seq_no=self.seq_no,
                               **self.license_kwargs)
        lbf.generate()
        self.seq_no += 1
        self.license_kwargs['capacity_limit'] += self.capacity_increment
        self.license_kwargs['capacity_hard_limit'] += self.capacity_increment
 
class LicenseBatchFile(object):
    """Represents a LBF and provides functionality for its construction."""

    def __init__(self, delivery_id, timestamp, fingerprints=[],
                 seq_no=1, elsn_id='FAKE_ELSN_ID', **license_kwargs):
        self.delivery_id = delivery_id
        self.timestamp = timestamp
        self.seq_no = seq_no
        self.license_kwargs = license_kwargs

        self.license_data = []
        elsn_num = 1
        for fp in fingerprints:
            data = (fp, elsn_id + str(elsn_num))
            self.license_data.append(data)
            elsn_num += 1
 
    def generate(self):
        s = 'Building batch %s, %s LKF(s)' % (self.delivery_id,
                                              len(self.license_data))
        print '-' * len(s), '\n', s, '\n', '-' * len(s)
        
        """mkdir(self.delivery_id)
        self.build_delivery_xml()"""

        for (fp, elsn_id) in self.license_data:
            lic = License(self.delivery_id, self.timestamp, 
                          fingerprint=fp, elsn_id=elsn_id,
                          seq_no=self.seq_no, **self.license_kwargs)
            print "Building", lic
            lic.generate()
        
        """self.to_zip()
        self.cleanup()"""

    def build_delivery_xml(self):
        delivery_file = DeliveryFile(self.delivery_id)
        for (fp, elsn_id) in self.license_data:
            delivery_file.add_target(fp, elsn_id)
        delivery_file.write()
    
    def to_zip(self):
        from os.path import walk, join, isfile
        from zipfile import ZipFile, ZIP_DEFLATED, ZIP_STORED
        filename = self.delivery_id + '.zip'
        zf = ZipFile(filename, 'w')
        zf.debug = 3
        
        def zipper(arg, dirname, names):
            for filename in names:
                path = join(dirname, filename)
                if isfile(path):
                    #print "Zipping", path
                    zf.write(path)

        walk(self.delivery_id, zipper, None)
        zf.close()

        # Let's test the archive as I've had some problems with it before.
        zf = ZipFile(filename, 'r')
        result = zf.testzip()
        zf.close()
        if result: raise Exception("Zip failed! Returned %a" % result)

    def cleanup(self):
        from shutil import rmtree
        rmtree(self.delivery_id)

class License(object):
    """License Key File and its associated files in a license batch.
    """

    def __init__(self, delivery_id, timestamp, elsn_id='FAKE_ELSN_ID',
                 fingerprint='ABCDEFG', seq_no=0, num_features=8,
                 num_capacities=2, capacity_limit=10, capacity_hard_limit=20,
                 start_date='2007-01-01',
                 stop_date='2009-12-31', **kwargs):
        self.delivery_id = delivery_id
        self.timestamp = timestamp
        self.elsn_id = elsn_id
        self.fingerprint = fingerprint
        self.seq_no = seq_no
        
        self.start_date = start_date
        self.stop_date = stop_date

        self.num_features = num_features
        self.capacity_limit = capacity_limit
        if capacity_hard_limit < capacity_limit:
            self.capacity_hard_limit = capacity_limit
        else:
            self.capacity_hard_limit = capacity_hard_limit
        self.capacities = num_capacities * [(capacity_limit, 
                                             capacity_hard_limit)]

    def generate(self):
        lkf = LicenseKeyFile(self.delivery_id, self.timestamp,
                             self.fingerprint, self.elsn_id,
                             self.seq_no, self.num_features, 
                             self.capacities, self.start_date,
                             self.stop_date)
        [f.write() for f in [lkf]]
    
    def __str__(self):
        s = ["License:"]
        s.append('Timestamp: %s' % self.timestamp)
        s.append('Fingerprint: %s' % self.fingerprint)
        s.append('ELSN ID: %s' % self.elsn_id)
        s.append('Sequence number: %s' % self.seq_no)
        s.append('Start date: %s' % self.start_date)
        s.append('Stop date: %s' % self.stop_date)
        s.append('Number of features: %s' % self.num_features)
        s.append('Number of capacities: %s (%s, %s)' % (len(self.capacities),
                                 self.capacity_limit,self.capacity_hard_limit))
        s.append('')
        return '\n   '.join(s)

### CLI ###

class ParseError(Exception):
    pass

def string_to_bool(a_bool):
    if a_bool == 'True' or a_bool == 'true' or a_bool == '1':
        return True
    elif a_bool == 'False' or a_bool == 'false' or a_bool == '0':
        return False
    else:
        raise Exception('%s can not be interpreted as a boolean' % a_bool)

class Argument(object):

    def __init__(self, flag, default, description):
        self.flag = flag
        self.value = default
        self.description = description
        self.takes_many_values = False
        self.num_args_parsed = 0

    def got_needed_values(self):
        return self.num_args_parsed > 0

    def parse_argument(self, arg):
        self.num_args_parsed += 1
        if not self.takes_many_values and self.num_args_parsed > 1:
            raise ParseError(self.flag + " can only be assigned one value!")
        else:
            self.parse(arg)

    def parse(self, arg):
        raise NotImplementedError("Implement in subclass!")

    def __str__(self):
        return "-%s %s" % (self.flag, self.value)

class SingleArgument(Argument):

    def parse(self, arg):
        self.value = arg

class IntegerArgument(Argument):

    def parse(self, arg):
        self.value = int(arg)

class BooleanArgument(Argument):

    def parse(self, arg):
        self.value = string_to_bool(arg)

    def __str__(self):
        if self.value:
            value = "True"
        else:
            value = "False"
        return "-%s %s" % (self.flag, value)

class MultipleArguments(Argument):

    def __init__(self, flag, default, description):
        super(MultipleArguments, self).__init__(flag, default, description)
        self.is_parsing_new_arguments = False
        self.takes_many_values = True

    def parse(self, arg):
        if not self.is_parsing_new_arguments:
            self.is_parsing_new_arguments = True
            self.value = [arg]
        else:
            self.value.append(arg)
    
    def __str__(self):
        return "-%s %s" % (self.flag, " ".join(self.value))

def setup_args():
    """Returns valid parameters with default values that the user can give as
    flags when invoking the script. The dictionary can then be used for the
    arguments needed by a LicenseMaker.
    """
    args = []
    args.append(SingleArgument('name', 'FAKE_LKF', 
                               'Name, or delivery id, of the batch and lkfs.'))
    args.append(SingleArgument('elsn_id', 'FAKE_ELSN_ID',
                               'The ELSN_ID name. An integer will be '
                               'appended for each fingerprint.'))
    args.append(MultipleArguments('fingerprints', ['X123', 'Y456'],
               'The fingerprints for which LKF:s will be generated and added '
               'to each batch file.'))
    args.append(IntegerArgument('seq_no', 1, 'Sequence number of the lkfs in '
                                'the first batch.'))
    args.append(IntegerArgument('num_batches', 1, 
                                'Number of batch files to generate. seq_no '
                                'will be incremented by one for each new '
                                'batch.'))
    args.append(IntegerArgument('num_capacities', 2,
                                'Base capacity for each capacity field.'))
    args.append(IntegerArgument('capacity_limit', 10,
                                'Base capacity for each capacity field.'))
    # XXX Seems like this doc isn't entirely correct! hard_limit is not
    # set to capacity at the moment!
    args.append(IntegerArgument('capacity_hard_limit', 0,
                                'Hard limit of each capacity. If lower than '
                                'capacity it will get the same value as '
                                '-capacity_limit.'))
    args.append(IntegerArgument('capacity_increment', 0,
                                'For each batch file, increment the capacity '
                                'values with this amount.'))
    # TODO Here we should handle capacity specifications!
    args.append(IntegerArgument('num_features', 8, 
                               'Number of features in each license.'))
    args.append(SingleArgument('start_date', '2007-01-01', 
                               'Feature/Capacity start date in format '
                               'YYYY-MM-DD'))
    args.append(SingleArgument('stop_date', '2099-12-31', 
                               "Feature/Capacity stop date. 'never' is also "
                               "a valid argument."))
    return args

def parse_argv(argv):
    """Parse argv and return a keyword argument dictionary."""
    args = dict()
    for arg in setup_args(): # set up a dictionary for the arguments 
        args[arg.flag] = arg
    current_arg = None
    for token in argv[1:]:
        if token.startswith('-'):
            flag = token[1:]
            if current_arg and current_arg.got_needed_values():
                raise ParseError(current_arg.flag + " needs more values!")
            if flag in args.keys():
                current_arg = args[flag]
            else:
                raise ParseError(flag + " is not a valid flag!")
        else:
            current_arg.parse(token)
    # unavoidable duplication?
    if current_arg and current_arg.got_needed_values():
        raise ParseError(current_arg.flag + " needs more values!")
    # Now set up a dictionary usable as a keyword arguments
    kwargs = dict()
    for key, arg in args.iteritems():
        kwargs[key] = arg.value
    return kwargs

def parse_file(file_name):
    """We got args via file instead. It should contain the same thing as our
    normal argv-lists, but with newlines, comments etc. Clean up an pass to
    parse_argv.

    Comments are started by '#'.
    """
    f = file(file_name, 'r')
    argv = [file_name] # we pretend we are sys.argv
    for line in f:
        tokens = line.strip().split(' ')
        for token in tokens:
            if token == '' or token.startswith('#'):
                break
            else:
                argv.append(token)
    #print argv
    return parse_argv(argv)

def help():
    """Produce user help based on the default arguments and exit."""
    cmd = "jython generate_licenses.py"
    usage = cmd + " <filename> | -<a flag> <an argument> " \
                  "[-<another flag> <another argument> ...]"
    example = [cmd]
    args = setup_args()
    for arg in args:
        example.append(str(arg))
    print "This script generates License Key File batches, usable for testing"
    print "with NETSim CPP nodes. We can NOT install these licenses on real"
    print "CPP nodes!\n"
    print "Usage:\n", usage, "\n"
    print "All flags have default values and are therefore optional."
    print "Flags can either be given at the command line or be provided in a"
    print "file named <filename>"
    print "Available flags are:"
    for arg in args:
        print '-' + arg.flag + ": " + str(arg.description)
    print "\nExample usage, using default values:"
    print " ".join(example)
    print "or if the arguments are in a file:"
    print cmd, "my_keys.lkf"
    sys.exit(1)

###

if __name__ == '__main__':
    if '-help' in sys.argv or '-h' in sys.argv or 'help' in sys.argv:
        help()
    try:
        if len(sys.argv) > 1 and isfile(sys.argv[1]):
                kwargs = parse_file(sys.argv[1])
        else:    
            kwargs = parse_argv(sys.argv)
    except ParseError, e:
        print "ERROR!"
        print "Invalid usage:", str(e), "\n"
        help()
#    print kwargs
    license_maker = LicenseMaker(**kwargs)
    license_maker.generate()


