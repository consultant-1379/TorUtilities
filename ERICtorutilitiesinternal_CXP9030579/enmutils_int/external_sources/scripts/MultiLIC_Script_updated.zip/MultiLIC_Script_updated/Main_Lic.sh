#!/bin/bash 
chmod +x /tmp/MultiLIC_Script_updated/Gen_LKF.py /tmp/MultiLIC_Script_updated/Gen_LDF.sh /tmp/MultiLIC_Script_updated/SignReplace.sh
python /tmp/MultiLIC_Script_updated/Gen_LKF.py -fingerprints $1 -seq_no $2 
/tmp/MultiLIC_Script_updated/Gen_LDF.sh $3 $1 $2 

for a in `ls /tmp/temp_lkf |grep -i "info.xml"`
{
/tmp/MultiLIC_Script_updated/SignReplace.sh "/tmp/temp_lkf/$a"
}
