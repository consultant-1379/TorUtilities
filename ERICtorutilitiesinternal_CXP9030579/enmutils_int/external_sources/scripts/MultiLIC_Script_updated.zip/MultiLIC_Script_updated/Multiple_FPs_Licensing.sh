#!/bin/bash

chmod 775 /tmp/MultiLIC_Script_updated/Main_Lic.sh

FPs=$(( $# - 2 ))
echo "Number of fingerprints = $FPs"
seqNumber=`echo $* |awk '{ print $(NF-1)  }'`
TypeOfNode=`echo $* |awk '{ print $(NF)  }'`

for var in "${@:1:$((${#@} - 2))}"
do
  echo $seqNumber
  echo $TypeOfNode
  echo "creating License batch file for fingerprint= $var"
  chmod 775 /tmp/MultiLIC_Script_updated/Main_Lic.sh
  /tmp/MultiLIC_Script_updated/Main_Lic.sh $var $seqNumber $TypeOfNode
done
echo "***********************************************************"
echo "fingerprints are $var"
echo "NodeType is :$TypeOfNode"
echo "SeqNo is :$seqNumber"
echo "***********************************************************"
#rm -rf /var/opt/ericsson/nms_smo_srv/smo_file_store/Delivery/license.zip
zipFileName="license_${var}_${seqNumber}_${TypeOfNode}.zip"
echo "zip file name is $zipFileName"
zip -rj $zipFileName /tmp/temp_lkf/*
mv $zipFileName ~
rm -rf /tmp/temp_lkf
echo "license zip file with name $zipFileName has been created under your home folder"
