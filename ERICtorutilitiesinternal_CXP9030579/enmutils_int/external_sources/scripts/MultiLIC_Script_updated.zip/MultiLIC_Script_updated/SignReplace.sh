#!/bin/bash
new_signature=` java -jar /tmp/MultiLIC_Script_updated/signaturecalc.jar $1 |awk -F": " ' { print $2 } '|awk '{print $1}'`

old_signature=`cat $1 | grep -i "Signature" |awk -F">" ' { print $2 } '|awk -F"<" ' { print $1 } '`

#echo old_signature is=$old_signature
#echo new_signature is=$new_signature

cat $1 | sed s/"$old_signature"/"$new_signature"/ >temp.xml

mv temp.xml $1	



