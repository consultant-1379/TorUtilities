"""check empty except statement
"""
from __future__ import print_function
__revision__ = 0

try:
    __revision__ += 1
except Exception:
    print('error')
