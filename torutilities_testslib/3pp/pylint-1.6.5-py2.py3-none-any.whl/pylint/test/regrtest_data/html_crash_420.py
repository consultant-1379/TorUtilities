# -*- coding: utf-8 -*-
tag2struct = {u"#": "R_HEADER"
             ,u"£": "RDR_HEADER"
             ,u"µ": "RDR_DRAFT"
             }